import { useState, useRef, useEffect } from "react";
import jsPDF from "jspdf";

// ─── Types ────────────────────────────────────────────────────────────────────

type Severity = "low" | "moderate" | "high";

type Result = {
  severity: Severity;
  conditions: string[];
  explanation: string[];
  nextSteps: string[];
  whenToSeeDoctor: string[];
};

type UserProfile = {
  name: string;
  age: string;
  gender: string;
  weight: string;
  height: string;
};

// ─── localStorage helpers ─────────────────────────────────────────────────────

const PROFILE_KEY = "medcompass_profile_v1";

function loadProfile(): UserProfile | null {
  try {
    const raw = localStorage.getItem(PROFILE_KEY);
    return raw ? JSON.parse(raw) : null;
  } catch { return null; }
}

function saveProfile(p: UserProfile) {
  localStorage.setItem(PROFILE_KEY, JSON.stringify(p));
}

// ─── Symptom Data ─────────────────────────────────────────────────────────────

const SYMPTOMS = [
  { emoji: "🤒", label: "Fever",               id: "fever" },
  { emoji: "🤕", label: "Headache",             id: "headache" },
  { emoji: "🤧", label: "Runny Nose",           id: "runny-nose" },
  { emoji: "😮", label: "Cough",                id: "cough" },
  { emoji: "😮‍💨", label: "Shortness of Breath", id: "shortness-of-breath" },
  { emoji: "😴", label: "Fatigue",              id: "fatigue" },
  { emoji: "🤢", label: "Nausea",               id: "nausea" },
  { emoji: "🤮", label: "Vomiting",             id: "vomiting" },
  { emoji: "🦠", label: "Diarrhea",             id: "diarrhea" },
  { emoji: "🫁", label: "Chest Pain",           id: "chest-pain" },
  { emoji: "🫃", label: "Abdominal Pain",       id: "abdominal-pain" },
  { emoji: "🦴", label: "Body Aches",           id: "body-aches" },
  { emoji: "🦵", label: "Joint Pain",           id: "joint-pain" },
  { emoji: "💪", label: "Weakness",             id: "weakness" },
  { emoji: "🔴", label: "Skin Rash",            id: "skin-rash" },
  { emoji: "📏", label: "Growth Concerns",      id: "growth-concerns" },
  { emoji: "🥶", label: "Chills",               id: "chills" },
  { emoji: "🤪", label: "Dizziness",            id: "dizziness" },
  { emoji: "👁️", label: "Eye Irritation",       id: "eye-irritation" },
  { emoji: "🔊", label: "Sore Throat",          id: "sore-throat" },
];

// ─── Medical Knowledge Base ───────────────────────────────────────────────────

const SYMPTOM_RESULTS: Record<string, Omit<Result, "severity">> = {
  fever: {
    conditions: ["Viral infection (influenza or common cold)", "Bacterial infection", "Inflammatory immune response"],
    explanation: [
      "Fever is the immune system's natural defense — it raises body temperature to fight pathogens.",
      "A reading above 38°C (100.4°F) is clinically considered a fever.",
      "Duration and accompanying symptoms are key to identifying the cause.",
    ],
    nextSteps: [
      "Drink at least 8–10 glasses of water or clear fluids daily",
      "Rest and avoid physical exertion until temperature normalises",
      "Take acetaminophen or ibuprofen to bring down fever if above 38.5°C",
      "Monitor temperature every 4–6 hours",
    ],
    whenToSeeDoctor: [
      "Fever exceeds 39.5°C (103°F) or has lasted more than 3 days",
      "You experience stiff neck, severe headache, or confusion",
      "Fever occurs in a child under 3 months or an elderly person",
      "You have difficulty breathing alongside the fever",
    ],
  },
  headache: {
    conditions: ["Tension-type headache", "Dehydration or low blood sugar", "Migraine (especially if recurring)"],
    explanation: [
      "Tension headaches feel like a tight band around the forehead and are the most common type.",
      "Dehydration reduces blood volume, lowering oxygen delivery to the brain.",
      "Screen time, poor posture, and stress are frequent modern triggers.",
    ],
    nextSteps: [
      "Drink 500ml of water immediately and rest for 20 minutes",
      "Rest in a quiet, dimly lit room away from screens",
      "Apply a cold compress to the forehead or a warm pack to the neck",
      "Gentle neck, jaw, and shoulder stretches may relieve tension",
    ],
    whenToSeeDoctor: [
      "Headache described as 'the worst of your life' — seek emergency care",
      "Accompanied by fever, stiff neck, vision changes, or confusion",
      "Occurs more than 15 days per month (chronic headache pattern)",
      "Does not respond to over-the-counter pain relief after 2–3 days",
    ],
  },
  "runny-nose": {
    conditions: ["Common cold (rhinovirus)", "Seasonal allergic rhinitis", "Sinusitis or nasal polyps"],
    explanation: [
      "A runny nose results from excess mucus production triggered by infection or allergens.",
      "Viral colds typically improve within 7–10 days without medication.",
      "Allergic rhinitis is chronic and recurs with allergen exposure.",
    ],
    nextSteps: [
      "Use saline nasal spray 2–3 times daily to clear passages",
      "Stay hydrated with warm liquids like broth or herbal tea",
      "Try antihistamines (e.g. loratadine) if allergies are suspected",
      "Sleep with your head slightly elevated to ease drainage",
    ],
    whenToSeeDoctor: [
      "Symptoms persist beyond 10 days or worsen after initial improvement",
      "Nasal discharge becomes thick, green, or yellow for more than 7 days",
      "You develop facial pain or pressure suggesting sinusitis",
      "Symptoms significantly impact daily life or sleep",
    ],
  },
  cough: {
    conditions: ["Upper respiratory infection (cold or flu)", "Allergic airway irritation or post-nasal drip", "Gastro-oesophageal reflux (GERD)"],
    explanation: [
      "Coughing is a protective reflex to clear airways of mucus, irritants, or foreign particles.",
      "A productive (wet) cough removes mucus; a dry cough suggests irritation or acid reflux.",
      "Most post-infection coughs resolve within 2–3 weeks even after other symptoms clear.",
    ],
    nextSteps: [
      "Sip warm honey-lemon tea to soothe the throat and suppress cough reflex",
      "Use steam inhalation for 10 minutes twice daily",
      "Stay well hydrated to thin and mobilise mucus",
      "Sleep with head elevated to reduce post-nasal drip",
    ],
    whenToSeeDoctor: [
      "Cough produces blood or rust-coloured mucus",
      "Accompanied by difficulty breathing, wheezing, or chest pain",
      "Persists beyond 3 weeks (chronic cough requires investigation)",
      "Cough is severe enough to cause vomiting or affect sleep significantly",
    ],
  },
  "shortness-of-breath": {
    conditions: ["Respiratory infection (bronchitis, pneumonia)", "Asthma or allergy-triggered airway spasm", "Anxiety or panic-related breathing difficulty"],
    explanation: [
      "Shortness of breath indicates reduced airflow or oxygen exchange in the lungs.",
      "Infectious causes often accompany fever, cough, or chest tightness.",
      "Anxiety can mimic respiratory symptoms — slow breathing helps distinguish.",
    ],
    nextSteps: [
      "Sit upright and practice slow, deep diaphragmatic breathing",
      "Move to fresh air and away from dust, smoke, or allergens",
      "Avoid any strenuous physical activity until breathing normalises",
      "If prescribed, use your inhaler as directed",
    ],
    whenToSeeDoctor: [
      "Breathlessness is sudden, severe, or worsening rapidly",
      "Lips, fingernails, or face appear blue or grey",
      "Chest pain or pressure accompanies the difficulty breathing",
      "Symptoms persist at rest or with minimal activity — seek emergency care",
    ],
  },
  fatigue: {
    conditions: ["Sleep deprivation or disrupted sleep cycle", "Nutritional deficiency (iron, B12, vitamin D)", "Stress-related burnout or chronic fatigue"],
    explanation: [
      "Fatigue beyond normal tiredness can signal the body's need for rest or nutrients.",
      "Iron-deficiency anaemia is a leading and often undiagnosed cause of chronic fatigue.",
      "Persistent fatigue lasting more than 6 months warrants full medical evaluation.",
    ],
    nextSteps: [
      "Aim for 7–9 hours of quality, uninterrupted sleep each night",
      "Eat iron-rich foods: red meat, spinach, lentils, and fortified cereals",
      "Reduce caffeine after 2 PM and limit alcohol, which fragments sleep",
      "Take short walks or light exercise — gentle movement improves energy",
    ],
    whenToSeeDoctor: [
      "Fatigue persists for more than 2 weeks despite adequate rest",
      "Accompanied by unexplained weight loss, night sweats, or fever",
      "You feel breathless with minimal exertion",
      "Fatigue significantly impacts your ability to work or function",
    ],
  },
  nausea: {
    conditions: ["Gastroenteritis or food intolerance", "Motion sickness or vestibular imbalance", "Stress, anxiety, or medication side effect"],
    explanation: [
      "Nausea is a protective reflex triggered by the gut-brain axis responding to irritants.",
      "Viral gastroenteritis (stomach flu) is contagious and usually resolves in 1–3 days.",
      "Stress and anxiety can directly stimulate the vagus nerve, causing nausea.",
    ],
    nextSteps: [
      "Eat small, frequent bland meals — crackers, plain rice, or toast",
      "Sip fluids slowly in small amounts — avoid large gulps",
      "Avoid fatty, fried, or strongly-scented foods",
      "Try ginger tea or ginger chews, which have natural anti-nausea effects",
    ],
    whenToSeeDoctor: [
      "Vomiting persists more than 24 hours or you cannot keep fluids down",
      "Signs of dehydration: dry mouth, dark urine, dizziness when standing",
      "Nausea accompanies severe abdominal pain or blood in vomit",
      "You are pregnant — nausea with vomiting needs monitoring",
    ],
  },
  vomiting: {
    conditions: ["Gastroenteritis (stomach flu — viral or bacterial)", "Food poisoning or foodborne illness", "Inner ear disturbance or migraine-associated nausea"],
    explanation: [
      "Vomiting is the body forcefully expelling stomach contents as a protective response.",
      "Food poisoning typically begins 1–6 hours after eating contaminated food.",
      "Repeated vomiting causes dehydration and electrolyte imbalance — these need attention.",
    ],
    nextSteps: [
      "Do not eat solid food for 1–2 hours after vomiting; sip water in tiny amounts",
      "Gradually reintroduce bland foods: toast, crackers, banana, rice",
      "Oral rehydration salts (ORS) replace lost electrolytes effectively",
      "Rest lying on your side to prevent aspiration if vomiting recurs",
    ],
    whenToSeeDoctor: [
      "Vomiting lasts more than 24 hours or you cannot keep any fluids down",
      "Blood or dark coffee-ground material appears in vomit",
      "Accompanied by severe abdominal pain, high fever, or stiff neck",
      "Signs of serious dehydration: no urination, extreme thirst, sunken eyes",
    ],
  },
  diarrhea: {
    conditions: ["Viral gastroenteritis (most common cause)", "Bacterial infection from contaminated food or water", "Irritable bowel syndrome (IBS) or food intolerance"],
    explanation: [
      "Diarrhea is loose, watery stools occurring more than 3 times a day.",
      "The gut speeds up transit time to flush out pathogens or irritants quickly.",
      "Most acute diarrhea resolves within 2–3 days with proper hydration.",
    ],
    nextSteps: [
      "Drink plenty of fluids — oral rehydration salts are the gold standard",
      "Eat the BRAT diet: Bananas, Rice, Applesauce, Toast",
      "Avoid dairy, caffeine, alcohol, and fatty or spicy foods",
      "Wash hands thoroughly and frequently to prevent spreading infection",
    ],
    whenToSeeDoctor: [
      "Diarrhea lasts more than 3 days without improvement",
      "Blood or mucus appears in stools",
      "Severe abdominal cramping or high fever (above 38.5°C) accompanies it",
      "Signs of dehydration: extreme thirst, no urination, dizziness, dry skin",
    ],
  },
  "chest-pain": {
    conditions: ["Musculoskeletal chest wall pain (most common)", "Acid reflux (GERD) causing heartburn", "Respiratory infection with pleuritis — seek evaluation"],
    explanation: [
      "Most chest pain is not cardiac in origin — muscle strain and acid reflux are very common causes.",
      "Chest pain that worsens when pressing on the chest wall is usually musculoskeletal.",
      "However, chest pain should always be taken seriously until a cardiac cause is excluded.",
    ],
    nextSteps: [
      "Stop any physical activity and sit or lie down comfortably",
      "If acid reflux is suspected, avoid lying flat and eat smaller meals",
      "For muscle pain, apply a warm compress and take an anti-inflammatory",
      "Seek immediate evaluation if pain is crushing, spreads to arm or jaw, or is severe",
    ],
    whenToSeeDoctor: [
      "Chest pain is severe, crushing, or pressure-like — call emergency services",
      "Pain radiates to the left arm, jaw, back, or shoulder",
      "Accompanied by shortness of breath, sweating, or nausea",
      "You have a history of heart disease or are over 40 — always get checked",
    ],
  },
  "abdominal-pain": {
    conditions: ["Indigestion, bloating, or gas (most common)", "Gastroenteritis or irritable bowel syndrome", "Appendicitis or other structural causes — needs evaluation"],
    explanation: [
      "Abdominal pain is one of the most common complaints and usually has a benign cause.",
      "Location matters: right-lower pain may suggest appendicitis; upper-central pain often relates to the stomach.",
      "Pain that comes and goes with meals is usually digestive; constant severe pain warrants urgent attention.",
    ],
    nextSteps: [
      "Avoid solid foods for a few hours; sip clear fluids gently",
      "Apply a warm compress or heating pad to the abdomen",
      "Avoid pain relievers like ibuprofen that can irritate the stomach lining",
      "Note when pain occurs — before meals, after meals, or at rest",
    ],
    whenToSeeDoctor: [
      "Severe, worsening pain — especially in the lower right abdomen",
      "Accompanied by high fever, vomiting, or inability to pass gas or stools",
      "Pain after abdominal trauma or injury",
      "Sudden onset of severe pain anywhere in the abdomen — seek emergency care",
    ],
  },
  "body-aches": {
    conditions: ["Viral illness (influenza, COVID-19)", "Post-exercise muscle soreness (DOMS)", "Fibromyalgia or chronic widespread pain"],
    explanation: [
      "During infection, the immune system releases cytokines that cause widespread muscle aching.",
      "DOMS peaks 24–48 hours after unfamiliar exercise and resolves on its own.",
      "Fibromyalgia causes persistent aches and is often linked to sleep disturbance.",
    ],
    nextSteps: [
      "Rest and avoid heavy physical activity during illness-related aches",
      "Warm baths, heating pads, or hot showers can relieve muscle tension",
      "Ibuprofen or naproxen can reduce inflammation-related aching",
      "Gentle stretching and staying hydrated supports muscle recovery",
    ],
    whenToSeeDoctor: [
      "Aches are severe, localised to one area, or associated with swelling",
      "Accompany high fever, rash, or breathing difficulty",
      "Persist beyond 1 week without improvement",
      "Chronic and affecting daily activities for months",
    ],
  },
  "joint-pain": {
    conditions: ["Osteoarthritis (wear-and-tear joint degeneration)", "Reactive arthritis or post-infectious inflammation", "Rheumatoid arthritis or autoimmune joint disease"],
    explanation: [
      "Joint pain (arthralgia) can involve any joint and ranges from mild to debilitating.",
      "Osteoarthritis is the most common form, typically affecting knees, hips, and hands.",
      "Sudden joint pain with redness and warmth may indicate infection or gout.",
    ],
    nextSteps: [
      "Rest the affected joint and avoid high-impact activities",
      "Apply ice for 20 minutes to reduce acute inflammation, then warm compress for stiffness",
      "Take ibuprofen or naproxen to reduce pain and swelling",
      "Gentle range-of-motion exercises maintain mobility without stressing the joint",
    ],
    whenToSeeDoctor: [
      "Joint is hot, severely swollen, or red — may indicate infection or gout",
      "Pain follows an injury or trauma to the joint",
      "Multiple joints are affected simultaneously",
      "Pain lasts more than 2–3 weeks or is progressively worsening",
    ],
  },
  weakness: {
    conditions: ["Generalised weakness from viral illness or infection", "Anaemia or nutritional deficiency", "Dehydration or electrolyte imbalance"],
    explanation: [
      "Weakness during illness is the body redirecting energy to the immune system.",
      "Anaemia reduces the oxygen-carrying capacity of blood, causing fatigue and weakness.",
      "Sudden or one-sided weakness is a red-flag symptom requiring immediate evaluation.",
    ],
    nextSteps: [
      "Rest completely and avoid strenuous activity",
      "Ensure adequate nutrition — eat protein and iron-rich foods",
      "Stay well hydrated with water and electrolyte drinks",
      "Avoid standing for long periods if weakness causes unsteadiness",
    ],
    whenToSeeDoctor: [
      "Weakness is sudden, severe, or affects one side of the body — seek emergency care",
      "Accompanied by slurred speech, facial drooping, or vision changes (stroke signs)",
      "Progressive weakness over days or weeks without a clear cause",
      "Weakness with difficulty swallowing or breathing",
    ],
  },
  "skin-rash": {
    conditions: ["Allergic contact dermatitis or eczema flare", "Viral exanthem (rash caused by viral infection)", "Urticaria (hives) from allergic reaction"],
    explanation: [
      "Skin rashes have many causes — most are not dangerous but some need prompt attention.",
      "A rash appearing alongside fever and other symptoms may indicate a systemic infection.",
      "Contact dermatitis develops within hours of exposure to an irritant or allergen.",
    ],
    nextSteps: [
      "Avoid scratching — it damages skin and increases infection risk",
      "Apply a gentle, fragrance-free moisturiser or cool compress to soothe the area",
      "Take an antihistamine (e.g. cetirizine) if itching is severe",
      "Identify and avoid potential triggers: new soaps, foods, plants, or medications",
    ],
    whenToSeeDoctor: [
      "Rash is spreading rapidly, blistering, or covers large areas of the body",
      "Accompanied by difficulty breathing, throat swelling, or dizziness — anaphylaxis emergency",
      "Rash appears as small red/purple dots that don't fade when pressed (non-blanching)",
      "Fever and rash together, especially in children — seek prompt evaluation",
    ],
  },
  "growth-concerns": {
    conditions: ["Normal growth variation (most common)", "Growth hormone deficiency (rare)", "Nutritional insufficiency affecting bone development"],
    explanation: [
      "Growth rates vary widely between individuals — most differences are completely normal.",
      "Peak height velocity in girls occurs around ages 11–13; in boys around ages 13–15.",
      "Adequate protein, calcium, vitamin D, and sleep are essential for healthy growth.",
    ],
    nextSteps: [
      "Ensure a balanced diet rich in protein, dairy or calcium-fortified foods, and vegetables",
      "Get 8–10 hours of quality sleep — growth hormone is primarily released during deep sleep",
      "Engage in regular physical activity, especially weight-bearing exercise",
      "Plot height and weight on a growth chart to track percentile trends over time",
    ],
    whenToSeeDoctor: [
      "No height increase for 12+ months in a child or teenager",
      "Child falls significantly below the expected growth percentile for their age",
      "Very early puberty (before age 8 in girls, 9 in boys) or significantly delayed puberty",
      "Growth concern is causing emotional distress — a paediatrician can reassure and assess",
    ],
  },
  chills: {
    conditions: ["Onset of systemic infection (viral or bacterial)", "Influenza or severe cold", "Medication reaction or cold exposure"],
    explanation: [
      "Chills result from rapid muscle contractions designed to generate body heat.",
      "They typically precede a fever as the body's thermostat resets upward.",
      "Chills without fever may indicate low blood sugar, anxiety, or hormonal changes.",
    ],
    nextSteps: [
      "Layer up with warm clothing and blankets — do not suppress shivering artificially",
      "Drink warm fluids: herbal teas, warm broth, or warm water with honey",
      "Rest in a warm room and monitor body temperature every few hours",
      "Check blood sugar if diabetic or if you haven't eaten recently",
    ],
    whenToSeeDoctor: [
      "Chills are severe or accompanied by high fever (above 39°C)",
      "Accompanied by rapid heart rate, confusion, or difficulty breathing",
      "Chills recur cyclically without explanation (may indicate malaria or other infection)",
      "You are immunocompromised, elderly, or an infant — seek earlier care",
    ],
  },
  dizziness: {
    conditions: ["Orthostatic hypotension (standing up too quickly)", "Benign paroxysmal positional vertigo (BPPV)", "Anaemia, low blood sugar, or dehydration"],
    explanation: [
      "BPPV — the most common cause of vertigo — results from displaced crystals in the inner ear.",
      "Sudden drops in blood pressure when standing temporarily reduce brain blood flow.",
      "Low blood sugar and dehydration both impair brain function, causing lightheadedness.",
    ],
    nextSteps: [
      "Sit or lie down immediately to prevent falling — safety first",
      "Drink water and have a small snack if you haven't eaten recently",
      "Rise slowly from sitting or lying positions — give the body time to adjust",
      "Avoid sudden head movements; move slowly and deliberately",
    ],
    whenToSeeDoctor: [
      "Dizziness is sudden, severe, or accompanied by severe headache",
      "Accompanied by chest pain, difficulty breathing, or fainting",
      "You experience hearing loss, ringing in ears, or facial numbness",
      "Dizziness is recurrent or has not resolved after 24–48 hours",
    ],
  },
  "eye-irritation": {
    conditions: ["Allergic conjunctivitis", "Digital eye strain (computer vision syndrome)", "Bacterial or viral conjunctivitis (pink eye)"],
    explanation: [
      "Allergens trigger histamine release in the conjunctiva, causing itching and redness.",
      "Prolonged screen use reduces blink rate, causing dryness and fatigue.",
      "Infectious conjunctivitis is highly contagious via hand-to-eye contact.",
    ],
    nextSteps: [
      "Avoid rubbing eyes — it spreads infection and worsens irritation",
      "Apply preservative-free artificial tears 3–4 times daily for dryness",
      "Use the 20-20-20 rule: every 20 min, look 20 ft away for 20 sec",
      "Wash hands frequently and avoid sharing towels or pillowcases",
    ],
    whenToSeeDoctor: [
      "Eye discharge is yellow/green or crusting — indicates bacterial infection",
      "Vision becomes blurry or light sensitivity develops",
      "Pain inside the eye (not just surface irritation)",
      "Symptoms worsen or do not improve after 48–72 hours of home care",
    ],
  },
  "sore-throat": {
    conditions: ["Viral pharyngitis (most common — cold, flu)", "Streptococcal bacterial infection (strep throat)", "Acid reflux, dry air, or post-nasal drip"],
    explanation: [
      "Over 80% of sore throats are viral and do not require antibiotics.",
      "Strep throat is bacterial, spreads easily, and requires antibiotic treatment.",
      "A throat swab is the only reliable way to distinguish viral from bacterial causes.",
    ],
    nextSteps: [
      "Gargle with warm salt water (1/2 tsp salt in 250ml water) every 2–4 hours",
      "Sip warm honey-lemon drinks to coat and soothe the throat",
      "Use throat lozenges with benzocaine for temporary numbing relief",
      "Use a humidifier at night to keep air moist and reduce irritation",
    ],
    whenToSeeDoctor: [
      "Difficulty swallowing saliva or opening your mouth fully",
      "White patches or pus visible on the tonsils",
      "High fever (above 38.5°C) alongside sore throat",
      "Symptoms do not improve after 7 days of home treatment",
    ],
  },
};

// ─── Health Tips ──────────────────────────────────────────────────────────────

const HEALTH_TIPS = [
  { icon: "💧", tip: "Drink 8 glasses of water daily. Staying hydrated supports every organ in your body.", color: "#0284c7", bg: "#e0f2fe" },
  { icon: "😴", tip: "Adults need 7–9 hours of sleep. Poor sleep weakens immunity and raises disease risk.", color: "#7c3aed", bg: "#f5f3ff" },
  { icon: "🥗", tip: "Fill half your plate with fruits and vegetables. Fibre and vitamins keep you healthy.", color: "#059669", bg: "#ecfdf5" },
  { icon: "🚶", tip: "30 minutes of walking daily reduces heart disease risk by up to 35%.", color: "#0891b2", bg: "#ecfeff" },
  { icon: "🧴", tip: "Wash hands for 20 seconds with soap. It's the single most effective way to stop illness.", color: "#d97706", bg: "#fffbeb" },
  { icon: "🌞", tip: "Get 15–30 minutes of sunlight daily for vitamin D, mood, and immune health.", color: "#ea580c", bg: "#fff7ed" },
  { icon: "🧘", tip: "5 minutes of deep breathing daily reduces cortisol and supports heart health.", color: "#6d28d9", bg: "#faf5ff" },
  { icon: "🚭", tip: "Avoiding smoking reduces lung cancer risk by 90% and heart disease risk significantly.", color: "#dc2626", bg: "#fef2f2" },
];

// ─── Growth Context ───────────────────────────────────────────────────────────

function getGrowthContext(ageNum: number): string | null {
  if (ageNum >= 8 && ageNum <= 20) {
    return `At age ${ageNum}, growth patterns vary widely and most differences are completely normal. Peak height velocity occurs at 11–13 in girls and 13–15 in boys. A paediatrician can plot your growth on a chart to confirm development is on track.`;
  }
  if (ageNum > 20 && ageNum <= 25) {
    return `Most people reach final adult height by their mid-twenties. Focus on bone health — adequate calcium, vitamin D, and weight-bearing exercise — to maintain a strong skeleton.`;
  }
  return null;
}

// ─── Result Builder ───────────────────────────────────────────────────────────

function buildResult(
  primaryId: string | undefined,
  customSymptoms: string[],
  painLevel: number,
  ageNum: number,
  durationDays: number,
): Result {
  const base = (primaryId && SYMPTOM_RESULTS[primaryId])
    ? { ...SYMPTOM_RESULTS[primaryId] }
    : {
        conditions: ["General viral or bacterial illness", "Stress-related physical response", "Early-stage infection"],
        explanation: [
          "Your combination of symptoms suggests a mild to moderate health issue.",
          "Multiple symptoms together often indicate your immune system is active.",
          "Monitoring closely is key — most common illnesses resolve within a week.",
        ],
        nextSteps: [
          "Rest and avoid strenuous activity",
          "Drink 8–10 glasses of water or clear fluids daily",
          "Eat nutritious, easy-to-digest foods",
          "Keep a symptom diary noting any changes",
        ],
        whenToSeeDoctor: [
          "Symptoms worsen significantly after 2–3 days",
          "You develop a high fever, breathing difficulty, or severe pain",
          "Symptoms last more than 5–7 days without improvement",
          "You are elderly, pregnant, or immunocompromised",
        ],
      };

  let severity: Severity;
  if (painLevel >= 7 || durationDays >= 14) severity = "high";
  else if (painLevel >= 4 || durationDays >= 5) severity = "moderate";
  else severity = "low";

  if (primaryId === "shortness-of-breath" || primaryId === "chest-pain") severity = "high";

  const growthNote = getGrowthContext(ageNum);
  const explanation = growthNote ? [...base.explanation, growthNote] : base.explanation;

  const nextSteps = durationDays >= 7
    ? [...base.nextSteps, "Symptoms lasting over a week warrant a medical appointment even if mild"]
    : base.nextSteps;

  const conditions = customSymptoms.length > 0
    ? [...base.conditions, `Additional symptoms (${customSymptoms.join(", ")}) may be related or indicate a separate condition`]
    : base.conditions;

  return { severity, conditions, explanation, nextSteps, whenToSeeDoctor: base.whenToSeeDoctor };
}

// ─── Constants ────────────────────────────────────────────────────────────────

const SEVERITY_CONFIG = {
  low:      { label: "Mild",     color: "#16a34a", bg: "#f0fdf4", border: "#bbf7d0", dot: "#22c55e" },
  moderate: { label: "Moderate", color: "#d97706", bg: "#fffbeb", border: "#fde68a", dot: "#f59e0b" },
  high:     { label: "Serious",  color: "#dc2626", bg: "#fef2f2", border: "#fecaca", dot: "#ef4444" },
};

const PAIN_LABELS: Record<number, { label: string; color: string; bg: string }> = {
  1:  { label: "No pain",       color: "#16a34a", bg: "#f0fdf4" },
  2:  { label: "Very mild",     color: "#22c55e", bg: "#f0fdf4" },
  3:  { label: "Mild",          color: "#65a30d", bg: "#f7fee7" },
  4:  { label: "Uncomfortable", color: "#ca8a04", bg: "#fefce8" },
  5:  { label: "Moderate",      color: "#d97706", bg: "#fffbeb" },
  6:  { label: "Distracting",   color: "#ea580c", bg: "#fff7ed" },
  7:  { label: "Severe",        color: "#dc2626", bg: "#fef2f2" },
  8:  { label: "Very severe",   color: "#b91c1c", bg: "#fef2f2" },
  9:  { label: "Excruciating",  color: "#991b1b", bg: "#fff1f2" },
  10: { label: "Unbearable",    color: "#7f1d1d", bg: "#fff1f2" },
};

const PAIN_EMOJI = (p: number) => p <= 2 ? "😊" : p <= 4 ? "😐" : p <= 6 ? "😟" : p <= 8 ? "😣" : "😭";

// ─── PDF Generator ────────────────────────────────────────────────────────────

function generatePDF(params: {
  profile: UserProfile; durationDays: string; painLevel: number;
  selectedSymptoms: string[]; customSymptoms: string[];
  result: Result; severity: typeof SEVERITY_CONFIG["low"];
}) {
  const { profile, durationDays, painLevel, selectedSymptoms, customSymptoms, result, severity } = params;
  const doc = new jsPDF({ orientation: "portrait", unit: "mm", format: "a4" });
  const pageW = doc.internal.pageSize.getWidth();
  const pageH = doc.internal.pageSize.getHeight();
  const margin = 18;
  const contentW = pageW - margin * 2;
  let y = 20;

  const nl = (n = 4) => { y += n; };

  const addText = (text: string, opts: { size?: number; bold?: boolean; color?: [number,number,number]; align?: "left"|"center"|"right"; indent?: number } = {}) => {
    doc.setFontSize(opts.size ?? 10);
    doc.setFont("helvetica", opts.bold ? "bold" : "normal");
    doc.setTextColor(...(opts.color ?? [30, 30, 30]));
    const x = opts.align === "center" ? pageW / 2 : opts.align === "right" ? pageW - margin : margin + (opts.indent ?? 0);
    const lines = doc.splitTextToSize(text, contentW - (opts.indent ?? 0));
    doc.text(lines, x, y, { align: opts.align ?? "left" });
    y += lines.length * ((opts.size ?? 10) * 0.45 + 1.5);
  };

  const addHR = (color: [number,number,number] = [220,220,220]) => {
    nl(2); doc.setDrawColor(...color); doc.line(margin, y, pageW - margin, y); nl(4);
  };

  const addSectionHeader = (icon: string, title: string, color: [number,number,number]) => {
    doc.setFillColor(...color);
    doc.roundedRect(margin, y, contentW, 9, 2, 2, "F");
    doc.setFontSize(10); doc.setFont("helvetica", "bold"); doc.setTextColor(255, 255, 255);
    doc.text(`${icon}  ${title}`, margin + 4, y + 6);
    nl(13);
  };

  const addBullet = (text: string, color: [number,number,number]) => {
    const clean = text.replace(/^[\p{Emoji}\s•–-]+/u, "").trim();
    doc.setFillColor(...color);
    doc.circle(margin + 2.5, y - 1, 1.2, "F");
    doc.setFontSize(9.5); doc.setFont("helvetica", "normal"); doc.setTextColor(55, 65, 81);
    const lines = doc.splitTextToSize(clean, contentW - 9);
    doc.text(lines, margin + 6, y);
    y += lines.length * 5 + 2;
  };

  // Header
  doc.setFillColor(2, 132, 199); doc.rect(0, 0, pageW, 28, "F");
  doc.setFillColor(5, 150, 105); doc.rect(0, 23, pageW, 5, "F");
  doc.setFontSize(18); doc.setFont("helvetica", "bold"); doc.setTextColor(255, 255, 255);
  doc.text("MedCompass", margin, 17);
  doc.setFontSize(8.5); doc.setFont("helvetica", "normal");
  doc.text("Health Assessment Report", margin, 24);
  doc.text(new Date().toLocaleDateString("en-US", { dateStyle: "long" }), pageW - margin, 24, { align: "right" });
  y = 38;

  // Patient Info Box
  const infoLines = [profile.gender, profile.weight ? `${profile.weight} kg` : "", profile.height ? `${profile.height} cm` : ""].filter(Boolean);
  const boxH = 34 + (infoLines.length > 0 ? 7 : 0);
  doc.setFillColor(240, 249, 255); doc.setDrawColor(186, 230, 253);
  doc.roundedRect(margin, y, contentW, boxH, 3, 3, "FD");
  y += 5;
  addText("PATIENT INFORMATION", { size: 8, bold: true, color: [2, 132, 199], indent: 4 });
  nl(1);
  doc.setFontSize(10); doc.setFont("helvetica", "normal"); doc.setTextColor(30, 30, 30);
  doc.text(`Name: ${profile.name || "—"}`, margin + 4, y);
  doc.text(`Age: ${profile.age || "—"}`, margin + 80, y); nl(6);
  doc.text(`Duration: ${durationDays} day${Number(durationDays) !== 1 ? "s" : ""}`, margin + 4, y);
  doc.text(`Pain Level: ${painLevel}/10 — ${PAIN_LABELS[painLevel]?.label ?? ""}`, margin + 60, y); nl(6);
  if (infoLines.length > 0) {
    doc.text(infoLines.join("   ·   "), margin + 4, y); nl(6);
  }
  doc.text(`Report date: ${new Date().toLocaleDateString()}`, margin + 4, y); nl(10);

  // Severity badge
  const sevRgb: [number,number,number] = result.severity === "low" ? [22,163,74] : result.severity === "moderate" ? [217,119,6] : [220,38,38];
  doc.setFillColor(...sevRgb); doc.roundedRect(margin, y, 42, 8, 2, 2, "F");
  doc.setFontSize(9); doc.setFont("helvetica", "bold"); doc.setTextColor(255, 255, 255);
  doc.text(`${severity.label.toUpperCase()} SEVERITY`, margin + 21, y + 5.5, { align: "center" });
  nl(14); addHR();

  // Sections
  addSectionHeader("📋", "REPORTED SYMPTOMS", [30, 64, 175]);
  const allSymptoms = [...selectedSymptoms, ...customSymptoms];
  if (allSymptoms.length === 0) {
    doc.setFontSize(10); doc.text("No symptoms recorded.", margin, y); nl(6);
  } else { allSymptoms.forEach(s => addBullet(s, [30, 64, 175])); }
  nl(2); addHR();

  addSectionHeader("🔬", "POSSIBLE CONDITIONS", [2, 132, 199]);
  result.conditions.forEach(c => addBullet(c, [2, 132, 199]));
  nl(2); addHR();

  addSectionHeader("📖", "EXPLANATION", [109, 40, 217]);
  result.explanation.forEach(e => addBullet(e, [109, 40, 217]));
  nl(2); addHR();

  addSectionHeader("✅", "RECOMMENDED NEXT STEPS", [5, 150, 105]);
  result.nextSteps.forEach(s => addBullet(s, [5, 150, 105]));
  nl(2); addHR();

  addSectionHeader("🏥", "WHEN TO SEE A DOCTOR", [220, 38, 38]);
  result.whenToSeeDoctor.forEach(w => addBullet(w, [220, 38, 38]));
  nl(4);

  // Disclaimer
  if (y > pageH - 45) { doc.addPage(); y = 20; }
  doc.setFillColor(254, 252, 232); doc.setDrawColor(253, 230, 138);
  doc.roundedRect(margin, y, contentW, 26, 3, 3, "FD");
  y += 5;
  doc.setFontSize(8.5); doc.setFont("helvetica", "bold"); doc.setTextColor(146, 64, 14);
  doc.text("Important Disclaimer", margin + 4, y); nl(5);
  doc.setFont("helvetica", "normal");
  const disc = "This tool provides general health information and is not a medical diagnosis. Always consult a qualified healthcare professional for any health concerns before making medical decisions.";
  const discLines = doc.splitTextToSize(disc, contentW - 8);
  doc.text(discLines, margin + 4, y);

  // Footer
  doc.setFontSize(7.5); doc.setFont("helvetica", "normal"); doc.setTextColor(156, 163, 175);
  doc.text("Generated by MedCompass · Not a substitute for professional medical advice", pageW / 2, pageH - 8, { align: "center" });

  doc.save(`MedCompass-Report-${profile.name || "Patient"}.pdf`);
}

// ─── Sub-components ───────────────────────────────────────────────────────────

function BulletList({ items, color }: { items: string[]; color: string }) {
  return (
    <ul style={{ margin: 0, padding: 0, listStyle: "none" }}>
      {items.map((item, i) => (
        <li key={i} style={{ display: "flex", alignItems: "flex-start", gap: "8px", marginBottom: i < items.length - 1 ? "8px" : "0" }}>
          <span style={{ width: "6px", height: "6px", borderRadius: "50%", background: color, flexShrink: 0, marginTop: "6px" }} />
          <span style={{ fontSize: "13px", color: "#374151", lineHeight: "1.6" }}>{item}</span>
        </li>
      ))}
    </ul>
  );
}

function SectionCard({ icon, title, children, accentColor, bgColor, borderColor }: {
  icon: string; title: string; children: React.ReactNode;
  accentColor: string; bgColor: string; borderColor: string;
}) {
  return (
    <div style={{ background: bgColor, border: `1.5px solid ${borderColor}`, borderRadius: "14px", padding: "14px 16px", marginBottom: "10px" }}>
      <div style={{ display: "flex", alignItems: "center", gap: "6px", marginBottom: "10px" }}>
        <span style={{ fontSize: "15px" }}>{icon}</span>
        <p style={{ margin: 0, fontSize: "11px", fontWeight: "700", color: accentColor, textTransform: "uppercase", letterSpacing: "0.6px" }}>{title}</p>
      </div>
      {children}
    </div>
  );
}

function HealthTipsCard() {
  const [tipIdx, setTipIdx] = useState(0);
  useEffect(() => {
    const t = setInterval(() => setTipIdx(i => (i + 1) % HEALTH_TIPS.length), 6000);
    return () => clearInterval(t);
  }, []);
  const tip = HEALTH_TIPS[tipIdx];
  return (
    <div style={{ background: tip.bg, border: `1.5px solid ${tip.color}33`, borderRadius: "18px", padding: "16px", marginBottom: "14px", boxShadow: "0 2px 12px rgba(0,0,0,0.05)" }}>
      <div style={{ display: "flex", alignItems: "center", gap: "8px", marginBottom: "8px" }}>
        <span style={{ fontSize: "18px" }}>{tip.icon}</span>
        <p style={{ margin: 0, fontSize: "11px", fontWeight: "700", color: tip.color, textTransform: "uppercase", letterSpacing: "0.5px" }}>Daily Health Tip</p>
        <span style={{ marginLeft: "auto", fontSize: "10px", color: "#9ca3af" }}>{tipIdx + 1}/{HEALTH_TIPS.length}</span>
      </div>
      <p style={{ margin: "0 0 10px", fontSize: "13px", color: "#374151", lineHeight: "1.6" }}>{tip.tip}</p>
      <div style={{ display: "flex", gap: "4px" }}>
        {HEALTH_TIPS.map((_, i) => (
          <button key={i} onClick={() => setTipIdx(i)} style={{ flex: 1, height: "4px", borderRadius: "2px", border: "none", background: i === tipIdx ? tip.color : "#e5e7eb", cursor: "pointer", padding: 0, transition: "background 0.3s" }} />
        ))}
      </div>
    </div>
  );
}

function FindDoctorButton() {
  const [locState, setLocState] = useState<"idle" | "loading" | "done">("idle");
  function handleClick() {
    if (!navigator.geolocation) { window.open("https://www.google.com/maps/search/doctors+near+me", "_blank"); return; }
    setLocState("loading");
    navigator.geolocation.getCurrentPosition(
      ({ coords }) => {
        setLocState("done");
        window.open(`https://www.google.com/maps/search/doctors/@${coords.latitude},${coords.longitude},14z`, "_blank");
        setTimeout(() => setLocState("idle"), 2000);
      },
      () => {
        setLocState("done");
        window.open("https://www.google.com/maps/search/doctors+near+me", "_blank");
        setTimeout(() => setLocState("idle"), 2000);
      },
      { timeout: 8000, maximumAge: 60000 },
    );
  }
  return (
    <button onClick={handleClick} disabled={locState === "loading"} style={{
      flex: "1 1 100px", padding: "12px 8px", borderRadius: "12px", border: "none",
      background: locState === "loading" ? "#e5e7eb" : "linear-gradient(135deg, #0284c7, #059669)",
      cursor: locState === "loading" ? "not-allowed" : "pointer", fontSize: "12px", fontWeight: "600",
      color: locState === "loading" ? "#6b7280" : "white",
      boxShadow: locState === "loading" ? "none" : "0 4px 14px rgba(2,132,199,0.3)", transition: "all 0.2s",
    }}>
      {locState === "loading" ? "📍 Locating…" : locState === "done" ? "✅ Opening…" : "📍 Find Doctor"}
    </button>
  );
}

// ─── Profile Screen ───────────────────────────────────────────────────────────

function ProfileScreen({ onComplete }: { onComplete: (p: UserProfile) => void }) {
  const [name, setName] = useState("");
  const [age, setAge] = useState("");
  const [gender, setGender] = useState("");
  const [weight, setWeight] = useState("");
  const [height, setHeight] = useState("");
  const [error, setError] = useState("");

  function handleSubmit() {
    if (!name.trim() || !age.trim() || !gender) {
      setError("Please fill in your name, age, and gender to continue.");
      return;
    }
    const profile: UserProfile = { name: name.trim(), age: age.trim(), gender, weight: weight.trim(), height: height.trim() };
    saveProfile(profile);
    onComplete(profile);
  }

  const genders = ["Male", "Female", "Non-binary", "Prefer not to say"];
  const inputStyle = (focused: boolean): React.CSSProperties => ({
    width: "100%", padding: "12px 14px", borderRadius: "12px",
    border: `1.5px solid ${focused ? "#0284c7" : "#e5e7eb"}`,
    fontSize: "14px", color: "#111827", background: "#f9fafb",
    boxSizing: "border-box", outline: "none", transition: "border-color 0.2s",
  });

  return (
    <div style={{ minHeight: "100vh", background: "linear-gradient(135deg, #e0f2fe 0%, #f0fdf4 50%, #e8f5e9 100%)", fontFamily: "'Inter', system-ui, sans-serif", display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", padding: "24px 16px" }}>
      <div style={{ width: "100%", maxWidth: "400px" }}>
        {/* Logo */}
        <div style={{ textAlign: "center", marginBottom: "28px" }}>
          <div style={{ width: "72px", height: "72px", borderRadius: "22px", background: "linear-gradient(135deg, #0284c7, #059669)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: "36px", margin: "0 auto 14px", boxShadow: "0 8px 28px rgba(2,132,199,0.35)" }}>🧭</div>
          <h1 style={{ margin: "0 0 6px", fontSize: "26px", fontWeight: "800", color: "#0f172a", letterSpacing: "-0.5px" }}>Welcome to MedCompass</h1>
          <p style={{ margin: 0, fontSize: "14px", color: "#6b7280", lineHeight: "1.5" }}>Create your health profile to get personalised symptom guidance.</p>
        </div>

        <div style={{ background: "white", borderRadius: "22px", padding: "24px 20px", boxShadow: "0 4px 24px rgba(0,0,0,0.08)" }}>

          {error && (
            <div style={{ background: "#fef2f2", border: "1.5px solid #fecaca", borderRadius: "12px", padding: "11px 14px", marginBottom: "16px", fontSize: "13px", color: "#991b1b" }}>
              ⚠️ {error}
            </div>
          )}

          {/* Name */}
          <div style={{ marginBottom: "14px" }}>
            <label style={{ display: "block", fontSize: "12px", fontWeight: "600", color: "#374151", marginBottom: "6px" }}>
              Full Name <span style={{ color: "#ef4444" }}>*</span>
            </label>
            <FocusInput value={name} onChange={v => { setName(v); setError(""); }} placeholder="Enter your full name" inputStyle={inputStyle} />
          </div>

          {/* Age */}
          <div style={{ marginBottom: "14px" }}>
            <label style={{ display: "block", fontSize: "12px", fontWeight: "600", color: "#374151", marginBottom: "6px" }}>
              Age <span style={{ color: "#ef4444" }}>*</span>
            </label>
            <FocusInput value={age} onChange={v => { setAge(v); setError(""); }} placeholder="e.g. 28" type="number" inputStyle={inputStyle} />
          </div>

          {/* Gender */}
          <div style={{ marginBottom: "14px" }}>
            <label style={{ display: "block", fontSize: "12px", fontWeight: "600", color: "#374151", marginBottom: "8px" }}>
              Gender <span style={{ color: "#ef4444" }}>*</span>
            </label>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "8px" }}>
              {genders.map(g => (
                <button key={g} onClick={() => { setGender(g); setError(""); }} style={{
                  padding: "10px", borderRadius: "10px", fontSize: "13px", fontWeight: "600", cursor: "pointer",
                  border: gender === g ? "2px solid #0284c7" : "2px solid #e5e7eb",
                  background: gender === g ? "linear-gradient(135deg, #e0f2fe, #dcfce7)" : "#f9fafb",
                  color: gender === g ? "#0284c7" : "#6b7280", transition: "all 0.2s",
                }}>{g}</button>
              ))}
            </div>
          </div>

          {/* Optional: weight + height */}
          <p style={{ margin: "0 0 10px", fontSize: "11px", color: "#9ca3af", fontWeight: "600", textTransform: "uppercase", letterSpacing: "0.5px" }}>Optional</p>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "10px", marginBottom: "20px" }}>
            <div>
              <label style={{ display: "block", fontSize: "12px", fontWeight: "600", color: "#374151", marginBottom: "6px" }}>Weight (kg)</label>
              <FocusInput value={weight} onChange={setWeight} placeholder="e.g. 70" type="number" inputStyle={inputStyle} />
            </div>
            <div>
              <label style={{ display: "block", fontSize: "12px", fontWeight: "600", color: "#374151", marginBottom: "6px" }}>Height (cm)</label>
              <FocusInput value={height} onChange={setHeight} placeholder="e.g. 170" type="number" inputStyle={inputStyle} />
            </div>
          </div>

          <button onClick={handleSubmit} style={{
            width: "100%", padding: "15px", borderRadius: "14px", border: "none", cursor: "pointer",
            background: "linear-gradient(135deg, #0284c7, #059669)", color: "white",
            fontSize: "15px", fontWeight: "700", letterSpacing: "0.2px",
            boxShadow: "0 6px 20px rgba(2,132,199,0.35)", transition: "all 0.2s",
          }}>
            Create My Profile →
          </button>

          <p style={{ margin: "12px 0 0", textAlign: "center", fontSize: "11px", color: "#9ca3af" }}>
            🔒 Saved privately on your device only
          </p>
        </div>

        <p style={{ textAlign: "center", fontSize: "11px", color: "#9ca3af", marginTop: "14px", lineHeight: "1.6" }}>
          This tool provides general health information only.<br />Always consult a qualified healthcare professional.
        </p>
      </div>
    </div>
  );
}

function FocusInput({ value, onChange, placeholder, type = "text", inputStyle }: {
  value: string; onChange: (v: string) => void; placeholder?: string; type?: string;
  inputStyle: (focused: boolean) => React.CSSProperties;
}) {
  const [focused, setFocused] = useState(false);
  return (
    <input type={type} value={value} placeholder={placeholder} onChange={e => onChange(e.target.value)}
      onFocus={() => setFocused(true)} onBlur={() => setFocused(false)}
      style={inputStyle(focused)} />
  );
}

// ─── Main Component ───────────────────────────────────────────────────────────

export default function MedCompass() {
  const [profile, setProfile] = useState<UserProfile | null>(() => loadProfile());
  const [patientName, setPatientName] = useState(() => loadProfile()?.name ?? "");
  const [age, setAge] = useState(() => loadProfile()?.age ?? "");
  const [durationDays, setDurationDays] = useState("");
  const [painLevel, setPainLevel] = useState(0);
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const [customSymptoms, setCustomSymptoms] = useState<string[]>([]);
  const [searchInput, setSearchInput] = useState("");
  const [showResults, setShowResults] = useState(false);
  const [loading, setLoading] = useState(false);
  const [validationError, setValidationError] = useState("");
  const resultsRef = useRef<HTMLDivElement>(null);
  const errorRef = useRef<HTMLDivElement>(null);

  const totalSymptoms = selected.size + customSymptoms.length;

  function handleProfileComplete(p: UserProfile) {
    setProfile(p);
    setPatientName(p.name);
    setAge(p.age);
  }

  if (!profile) {
    return <ProfileScreen onComplete={handleProfileComplete} />;
  }

  function toggleSymptom(id: string) {
    setSelected(prev => { const n = new Set(prev); n.has(id) ? n.delete(id) : n.add(id); return n; });
    setShowResults(false); setValidationError("");
  }

  function handleAddCustom() {
    const trimmed = searchInput.trim();
    if (!trimmed) return;
    const matchedId = SYMPTOMS.find(s => s.label.toLowerCase() === trimmed.toLowerCase())?.id;
    if (matchedId) {
      setSelected(prev => { const n = new Set(prev); n.add(matchedId); return n; });
    } else if (!customSymptoms.includes(trimmed)) {
      setCustomSymptoms(prev => [...prev, trimmed]);
    }
    setSearchInput(""); setShowResults(false); setValidationError("");
  }

  function removeCustom(sym: string) {
    setCustomSymptoms(prev => prev.filter(s => s !== sym)); setShowResults(false);
  }

  function validate(): boolean {
    const missing: string[] = [];
    if (!patientName.trim()) missing.push("patient name");
    if (!age.trim()) missing.push("age");
    if (totalSymptoms === 0) missing.push("symptoms");
    if (!durationDays.trim()) missing.push("duration");
    if (painLevel === 0) missing.push("pain level");
    if (missing.length > 0) {
      setValidationError(`Please enter all required information: ${missing.join(", ")}.`);
      setTimeout(() => errorRef.current?.scrollIntoView({ behavior: "smooth", block: "center" }), 50);
      return false;
    }
    setValidationError(""); return true;
  }

  function handleAnalyze() {
    if (!validate()) return;
    setShowResults(false); setLoading(true);
    setTimeout(() => {
      setLoading(false); setShowResults(true);
      setTimeout(() => resultsRef.current?.scrollIntoView({ behavior: "smooth", block: "start" }), 80);
    }, 2200);
  }

  function handleReset() {
    setDurationDays(""); setPainLevel(0); setSelected(new Set());
    setCustomSymptoms([]); setSearchInput(""); setShowResults(false);
    setLoading(false); setValidationError("");
  }

  function handleEditProfile() {
    if (confirm("Edit your profile? This will clear your current session.")) {
      localStorage.removeItem(PROFILE_KEY);
      setProfile(null); setPatientName(""); setAge(""); handleReset();
    }
  }

  const primarySymptom = Array.from(selected)[0];
  const ageNum = parseInt(age) || 0;
  const daysNum = parseInt(durationDays) || 0;
  const result = buildResult(primarySymptom, customSymptoms, painLevel, ageNum, daysNum);
  const severity = SEVERITY_CONFIG[result.severity];

  const selectedSymptomLabels = Array.from(selected).map(id => {
    const s = SYMPTOMS.find(x => x.id === id);
    return s ? `${s.emoji} ${s.label}` : id;
  });

  const suggestions = searchInput.length > 0
    ? SYMPTOMS.filter(s => s.label.toLowerCase().includes(searchInput.toLowerCase()) && !selected.has(s.id))
    : [];

  const painInfo = painLevel > 0 ? PAIN_LABELS[painLevel] : null;

  const fullProfile: UserProfile = { name: patientName, age, gender: profile.gender, weight: profile.weight, height: profile.height };

  return (
    <div style={{ minHeight: "100vh", background: "linear-gradient(135deg, #e0f2fe 0%, #f0fdf4 50%, #e8f5e9 100%)", fontFamily: "'Inter', system-ui, sans-serif", margin: 0, padding: 0 }}>
      <style>{`
        @keyframes ping { 0%,100%{transform:scale(1);opacity:0.4} 50%{transform:scale(1.4);opacity:0.1} }
        @keyframes progress { 0%{width:0%} 60%{width:75%} 100%{width:100%} }
        @keyframes fadeSlideUp { from{opacity:0;transform:translateY(10px)} to{opacity:1;transform:translateY(0)} }
        @keyframes ellipsis { 0%{width:0} 25%{width:.5em} 50%{width:1em} 75%{width:1.5em} 100%{width:0} }
        @keyframes shake { 0%,100%{transform:translateX(0)} 20%{transform:translateX(-6px)} 40%{transform:translateX(6px)} 60%{transform:translateX(-4px)} 80%{transform:translateX(4px)} }
        input:focus { outline:none; }
        button:active { transform:scale(0.97); }
      `}</style>

      <div style={{ maxWidth: "420px", margin: "0 auto", minHeight: "100vh", display: "flex", flexDirection: "column" }}>

        {/* ── Header ── */}
        <div style={{ background: "linear-gradient(135deg, #0284c7 0%, #0891b2 60%, #059669 100%)", padding: "24px 20px 32px", borderBottomLeftRadius: "28px", borderBottomRightRadius: "28px", boxShadow: "0 8px 32px rgba(2,132,199,0.25)", position: "relative", overflow: "hidden" }}>
          <div style={{ position: "absolute", top: "-20px", right: "-20px", width: "120px", height: "120px", background: "rgba(255,255,255,0.08)", borderRadius: "50%" }} />
          <div style={{ position: "absolute", bottom: "-30px", left: "30px", width: "80px", height: "80px", background: "rgba(255,255,255,0.06)", borderRadius: "50%" }} />
          <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
            <div style={{ display: "flex", alignItems: "center", gap: "12px" }}>
              <span style={{ fontSize: "30px" }}>🧭</span>
              <div>
                <h1 style={{ color: "white", fontSize: "22px", fontWeight: "700", margin: 0, lineHeight: "1.2", letterSpacing: "-0.5px" }}>MedCompass</h1>
                <p style={{ color: "rgba(255,255,255,0.75)", fontSize: "12px", margin: "2px 0 0" }}>Your personal health guide</p>
              </div>
            </div>
            {/* Profile badge */}
            <button onClick={handleEditProfile} style={{ background: "rgba(255,255,255,0.15)", border: "1px solid rgba(255,255,255,0.3)", borderRadius: "12px", padding: "8px 12px", cursor: "pointer", textAlign: "right", backdropFilter: "blur(8px)" }}>
              <p style={{ margin: 0, color: "white", fontSize: "12px", fontWeight: "700" }}>{profile.name.split(" ")[0]}</p>
              <p style={{ margin: 0, color: "rgba(255,255,255,0.7)", fontSize: "10px" }}>Age {profile.age} · {profile.gender}</p>
            </button>
          </div>
        </div>

        <div style={{ padding: "18px 16px", flex: 1 }}>

          {/* ── Health Tips ── */}
          <HealthTipsCard />

          {/* ── Validation Error ── */}
          {validationError && (
            <div ref={errorRef} style={{ background: "#fef2f2", border: "1.5px solid #fecaca", borderRadius: "14px", padding: "13px 16px", marginBottom: "14px", display: "flex", gap: "10px", alignItems: "flex-start", animation: "shake 0.4s ease, fadeSlideUp 0.3s ease" }}>
              <span style={{ fontSize: "18px", flexShrink: 0 }}>⚠️</span>
              <p style={{ margin: 0, fontSize: "13px", color: "#991b1b", fontWeight: "500", lineHeight: "1.5" }}>{validationError}</p>
            </div>
          )}

          {/* ── Patient Info ── */}
          <div style={{ background: "white", borderRadius: "18px", padding: "16px", marginBottom: "14px", boxShadow: "0 2px 12px rgba(0,0,0,0.06)" }}>
            <p style={{ margin: "0 0 12px", fontSize: "14px", fontWeight: "700", color: "#0284c7", display: "flex", alignItems: "center", gap: "6px" }}>👤 Patient Information</p>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "10px" }}>
              <div>
                <label style={{ display: "block", fontSize: "12px", fontWeight: "600", color: "#374151", marginBottom: "6px" }}>Name <span style={{ color: "#ef4444" }}>*</span></label>
                <input value={patientName} onChange={e => { setPatientName(e.target.value); setValidationError(""); }}
                  placeholder="Full name" style={{ width: "100%", padding: "10px 12px", borderRadius: "10px", border: "1.5px solid #e5e7eb", fontSize: "13px", background: "#f9fafb", boxSizing: "border-box", outline: "none" }}
                  onFocus={e => e.target.style.borderColor = "#0284c7"} onBlur={e => e.target.style.borderColor = "#e5e7eb"} />
              </div>
              <div>
                <label style={{ display: "block", fontSize: "12px", fontWeight: "600", color: "#374151", marginBottom: "6px" }}>Age <span style={{ color: "#ef4444" }}>*</span></label>
                <input type="number" value={age} onChange={e => { setAge(e.target.value); setValidationError(""); }}
                  placeholder="e.g. 25" style={{ width: "100%", padding: "10px 12px", borderRadius: "10px", border: "1.5px solid #e5e7eb", fontSize: "13px", background: "#f9fafb", boxSizing: "border-box", outline: "none" }}
                  onFocus={e => e.target.style.borderColor = "#0284c7"} onBlur={e => e.target.style.borderColor = "#e5e7eb"} />
              </div>
            </div>
            {(profile.weight || profile.height) && (
              <div style={{ marginTop: "8px", display: "flex", gap: "8px", flexWrap: "wrap" }}>
                {profile.weight && <span style={{ background: "#f0f9ff", border: "1px solid #bae6fd", borderRadius: "8px", padding: "4px 10px", fontSize: "12px", color: "#0284c7" }}>⚖️ {profile.weight} kg</span>}
                {profile.height && <span style={{ background: "#f0fdf4", border: "1px solid #bbf7d0", borderRadius: "8px", padding: "4px 10px", fontSize: "12px", color: "#059669" }}>📏 {profile.height} cm</span>}
              </div>
            )}
          </div>

          {/* ── Duration ── */}
          <div style={{ background: "white", borderRadius: "18px", padding: "16px", marginBottom: "14px", boxShadow: "0 2px 12px rgba(0,0,0,0.06)" }}>
            <p style={{ margin: "0 0 12px", fontSize: "14px", fontWeight: "700", color: "#0284c7" }}>📅 Duration of Symptoms <span style={{ color: "#ef4444" }}>*</span></p>
            <div style={{ display: "flex", gap: "8px", marginBottom: "10px", alignItems: "center" }}>
              <input type="number" min="1" value={durationDays} placeholder="Number of days"
                onChange={e => { setDurationDays(e.target.value); setValidationError(""); }}
                style={{ flex: 1, padding: "11px 13px", borderRadius: "10px", border: "1.5px solid #e5e7eb", fontSize: "14px", color: "#111827", background: "#f9fafb", outline: "none", boxSizing: "border-box" }}
                onFocus={e => e.target.style.borderColor = "#0284c7"} onBlur={e => e.target.style.borderColor = "#e5e7eb"} />
              <span style={{ fontSize: "13px", color: "#6b7280", fontWeight: "500" }}>days</span>
            </div>
            <div style={{ display: "flex", gap: "6px" }}>
              {[["1","1 day"],["3","3 days"],["7","1 week"],["14","2 weeks"]].map(([val, label]) => (
                <button key={val} onClick={() => { setDurationDays(val); setValidationError(""); }} style={{
                  flex: 1, padding: "7px 4px", borderRadius: "10px", border: "none", cursor: "pointer",
                  fontSize: "11px", fontWeight: durationDays === val ? "700" : "500",
                  background: durationDays === val ? "linear-gradient(135deg, #0284c7, #059669)" : "#f3f4f6",
                  color: durationDays === val ? "white" : "#6b7280", transition: "all 0.2s",
                }}>{label}</button>
              ))}
            </div>
          </div>

          {/* ── Pain Level ── */}
          <div style={{ background: "white", borderRadius: "18px", padding: "16px", marginBottom: "14px", boxShadow: "0 2px 12px rgba(0,0,0,0.06)" }}>
            <p style={{ margin: "0 0 2px", fontSize: "14px", fontWeight: "700", color: "#0284c7" }}>🌡️ Pain Level <span style={{ color: "#ef4444" }}>*</span></p>
            <p style={{ margin: "0 0 12px", fontSize: "11px", color: "#9ca3af" }}>1–3 = Mild &nbsp;·&nbsp; 4–6 = Moderate &nbsp;·&nbsp; 7–10 = Severe</p>
            <div style={{ display: "grid", gridTemplateColumns: "repeat(10, 1fr)", gap: "4px", marginBottom: "10px" }}>
              {Array.from({ length: 10 }, (_, i) => i + 1).map(n => {
                const isSelected = painLevel === n;
                const info = PAIN_LABELS[n];
                return (
                  <button key={n} onClick={() => { setPainLevel(n); setValidationError(""); }} style={{
                    padding: "10px 0", borderRadius: "8px", border: "none", cursor: "pointer",
                    fontWeight: "700", fontSize: "14px",
                    background: isSelected ? info.color : "#f3f4f6",
                    color: isSelected ? "white" : n <= 3 ? "#16a34a" : n <= 6 ? "#d97706" : "#dc2626",
                    transition: "all 0.15s",
                    transform: isSelected ? "scale(1.1)" : "scale(1)",
                    boxShadow: isSelected ? `0 4px 12px ${info.color}55` : "none",
                  }}>{n}</button>
                );
              })}
            </div>
            {painInfo && (
              <div style={{ background: painInfo.bg, borderRadius: "10px", padding: "10px 14px", display: "flex", alignItems: "center", gap: "10px", animation: "fadeSlideUp 0.2s ease" }}>
                <span style={{ fontSize: "22px" }}>{PAIN_EMOJI(painLevel)}</span>
                <div>
                  <p style={{ margin: 0, fontSize: "14px", fontWeight: "700", color: painInfo.color }}>{painInfo.label}</p>
                  <p style={{ margin: 0, fontSize: "11px", color: "#6b7280" }}>
                    {painLevel <= 3 ? "Mild range" : painLevel <= 6 ? "Moderate range" : "Severe range"} · Level {painLevel}/10
                  </p>
                </div>
              </div>
            )}
          </div>

          {/* ── Symptom Search ── */}
          <div style={{ background: "white", borderRadius: "18px", padding: "16px", marginBottom: "14px", boxShadow: "0 2px 12px rgba(0,0,0,0.06)", position: "relative" }}>
            <p style={{ margin: "0 0 10px", fontSize: "14px", fontWeight: "700", color: "#0284c7" }}>🔍 Search or type any symptom <span style={{ color: "#ef4444" }}>*</span></p>
            <div style={{ display: "flex", gap: "8px" }}>
              <input type="text" placeholder="e.g. chest tightness, rash, swelling…"
                value={searchInput} onChange={e => { setSearchInput(e.target.value); setValidationError(""); }}
                onKeyDown={e => e.key === "Enter" && handleAddCustom()}
                style={{ flex: 1, padding: "11px 13px", borderRadius: "10px", border: "1.5px solid #e5e7eb", fontSize: "13px", color: "#111827", background: "#f9fafb", outline: "none", boxSizing: "border-box" }}
                onFocus={e => e.target.style.borderColor = "#0284c7"} onBlur={e => e.target.style.borderColor = "#e5e7eb"} />
              <button onClick={handleAddCustom} disabled={!searchInput.trim()} style={{
                padding: "11px 14px", borderRadius: "10px", border: "none", fontSize: "13px", fontWeight: "600",
                background: searchInput.trim() ? "linear-gradient(135deg, #0284c7, #059669)" : "#e5e7eb",
                color: searchInput.trim() ? "white" : "#9ca3af",
                cursor: searchInput.trim() ? "pointer" : "not-allowed", whiteSpace: "nowrap",
              }}>Add +</button>
            </div>

            {suggestions.length > 0 && (
              <div style={{ position: "absolute", left: "16px", right: "16px", top: "calc(100% - 8px)", background: "white", border: "1.5px solid #bae6fd", borderRadius: "10px", boxShadow: "0 8px 24px rgba(0,0,0,0.1)", zIndex: 10, overflow: "hidden" }}>
                {suggestions.map(s => (
                  <button key={s.id} onMouseDown={() => { toggleSymptom(s.id); setSearchInput(""); }} style={{ width: "100%", textAlign: "left", padding: "10px 14px", border: "none", background: "white", cursor: "pointer", fontSize: "13px", color: "#374151", display: "flex", alignItems: "center", gap: "8px", borderBottom: "1px solid #f3f4f6" }}>
                    <span>{s.emoji}</span> {s.label}
                  </button>
                ))}
              </div>
            )}

            {customSymptoms.length > 0 && (
              <div style={{ marginTop: "10px", display: "flex", flexWrap: "wrap", gap: "6px" }}>
                {customSymptoms.map(sym => (
                  <span key={sym} style={{ background: "#faf5ff", border: "1.5px solid #ddd6fe", borderRadius: "20px", padding: "4px 10px", fontSize: "12px", color: "#6d28d9", fontWeight: "600", display: "flex", alignItems: "center", gap: "5px" }}>
                    ✏️ {sym}
                    <button onClick={() => removeCustom(sym)} style={{ background: "none", border: "none", cursor: "pointer", color: "#a78bfa", fontWeight: "700", padding: "0 0 0 2px", fontSize: "14px", lineHeight: 1 }}>×</button>
                  </span>
                ))}
              </div>
            )}
          </div>

          {/* ── Symptom Grid ── */}
          <div style={{ background: "white", borderRadius: "18px", padding: "16px", marginBottom: "16px", boxShadow: "0 2px 12px rgba(0,0,0,0.06)" }}>
            <p style={{ margin: "0 0 12px", fontSize: "14px", fontWeight: "700", color: "#0284c7", display: "flex", alignItems: "center", gap: "6px" }}>
              🩺 Quick Symptom Buttons
              {selected.size > 0 && <span style={{ background: "linear-gradient(135deg, #0284c7, #059669)", color: "white", borderRadius: "10px", padding: "2px 8px", fontSize: "11px", fontWeight: "700" }}>{selected.size} selected</span>}
            </p>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: "7px" }}>
              {SYMPTOMS.map(s => {
                const isSelected = selected.has(s.id);
                return (
                  <button key={s.id} onClick={() => toggleSymptom(s.id)} style={{
                    display: "flex", flexDirection: "column", alignItems: "center", padding: "11px 6px", borderRadius: "14px",
                    border: isSelected ? "2px solid #0284c7" : "2px solid #f3f4f6",
                    background: isSelected ? "linear-gradient(135deg, #e0f2fe, #dcfce7)" : "#fafafa",
                    cursor: "pointer", transition: "all 0.2s",
                    transform: isSelected ? "scale(0.97)" : "scale(1)",
                    boxShadow: isSelected ? "0 0 0 3px rgba(2,132,199,0.15)" : "none",
                  }}>
                    <span style={{ fontSize: "20px", marginBottom: "4px" }}>{s.emoji}</span>
                    <span style={{ fontSize: "10px", fontWeight: isSelected ? "600" : "400", color: isSelected ? "#0284c7" : "#6b7280", textAlign: "center", lineHeight: "1.2" }}>{s.label}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* ── Analyze Button ── */}
          <button onClick={handleAnalyze} disabled={loading} style={{
            width: "100%", padding: "16px", borderRadius: "16px", border: "none",
            cursor: loading ? "not-allowed" : "pointer", fontSize: "15px", fontWeight: "600",
            background: "linear-gradient(135deg, #0284c7 0%, #0891b2 50%, #059669 100%)",
            color: "white", marginBottom: "12px",
            boxShadow: "0 6px 20px rgba(2,132,199,0.35)", opacity: loading ? 0.7 : 1, letterSpacing: "0.3px",
          }}>
            🔍 Analyze Symptoms
          </button>

          {/* ── Loading ── */}
          {loading && (
            <div style={{ background: "white", borderRadius: "20px", padding: "32px 20px", marginBottom: "12px", boxShadow: "0 4px 24px rgba(0,0,0,0.08)", display: "flex", flexDirection: "column", alignItems: "center", gap: "20px", animation: "fadeSlideUp 0.3s ease" }}>
              <div style={{ position: "relative", width: "64px", height: "64px" }}>
                <div style={{ position: "absolute", inset: 0, borderRadius: "50%", background: "linear-gradient(135deg, #0284c7, #059669)", animation: "ping 1.2s cubic-bezier(0,0,0.2,1) infinite", opacity: 0.25 }} />
                <div style={{ position: "absolute", inset: "8px", borderRadius: "50%", background: "linear-gradient(135deg, #0284c7, #059669)", animation: "ping 1.2s cubic-bezier(0,0,0.2,1) infinite 0.4s", opacity: 0.35 }} />
                <div style={{ position: "absolute", inset: "16px", borderRadius: "50%", background: "linear-gradient(135deg, #0284c7, #059669)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: "18px" }}>🧬</div>
              </div>
              <div style={{ textAlign: "center" }}>
                <p style={{ margin: "0 0 6px", fontSize: "16px", fontWeight: "700", color: "#0f172a" }}>
                  Analysing your symptoms
                  <span style={{ display: "inline-block", animation: "ellipsis 1.4s steps(4,end) infinite", overflow: "hidden", verticalAlign: "bottom", width: "1.5em" }}>...</span>
                </p>
                <p style={{ margin: 0, fontSize: "13px", color: "#6b7280" }}>Checking conditions for {patientName}, age {age}</p>
              </div>
              <div style={{ width: "100%", background: "#f3f4f6", borderRadius: "999px", height: "6px", overflow: "hidden" }}>
                <div style={{ height: "100%", background: "linear-gradient(90deg, #0284c7, #059669)", borderRadius: "999px", animation: "progress 2.2s ease-in-out forwards" }} />
              </div>
              <div style={{ display: "flex", flexWrap: "wrap", gap: "6px", justifyContent: "center" }}>
                {[...selectedSymptomLabels, ...customSymptoms.map(s => `✏️ ${s}`)].map((label, i) => (
                  <span key={i} style={{ background: "linear-gradient(135deg, #e0f2fe, #dcfce7)", border: "1.5px solid #bae6fd", borderRadius: "20px", padding: "4px 10px", fontSize: "12px", color: "#0284c7", fontWeight: "600" }}>{label}</span>
                ))}
              </div>
            </div>
          )}

          {/* ── Results ── */}
          {showResults && (
            <div ref={resultsRef} style={{ background: "white", borderRadius: "20px", overflow: "hidden", boxShadow: "0 4px 24px rgba(0,0,0,0.08)", marginBottom: "12px", animation: "fadeSlideUp 0.4s ease" }}>
              <div style={{ background: "linear-gradient(135deg, #0284c7, #059669)", padding: "18px 20px" }}>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", gap: "10px" }}>
                  <div>
                    <p style={{ margin: "0 0 2px", color: "rgba(255,255,255,0.7)", fontSize: "11px", fontWeight: "500", letterSpacing: "0.5px", textTransform: "uppercase" }}>AI Assessment</p>
                    <h2 style={{ margin: "0 0 3px", color: "white", fontSize: "17px", fontWeight: "700" }}>Results for {patientName}</h2>
                    <p style={{ margin: 0, color: "rgba(255,255,255,0.75)", fontSize: "12px" }}>Age {age} · {durationDays} day{Number(durationDays) !== 1 ? "s" : ""} · Pain {painLevel}/10</p>
                  </div>
                  <span style={{ background: severity.bg, color: severity.color, border: `1px solid ${severity.border}`, borderRadius: "12px", padding: "5px 11px", fontSize: "12px", fontWeight: "700", whiteSpace: "nowrap", display: "flex", alignItems: "center", gap: "5px", flexShrink: 0 }}>
                    <span style={{ width: "6px", height: "6px", borderRadius: "50%", background: severity.dot, display: "inline-block" }} />
                    {severity.label}
                  </span>
                </div>
              </div>

              <div style={{ padding: "16px 16px 4px" }}>
                <SectionCard icon="🔬" title="Possible Conditions" accentColor="#0284c7" bgColor="#f0f9ff" borderColor="#bae6fd">
                  <BulletList items={result.conditions} color="#0284c7" />
                </SectionCard>
                <SectionCard icon="📖" title="Explanation" accentColor="#6d28d9" bgColor="#faf5ff" borderColor="#ddd6fe">
                  <BulletList items={result.explanation} color="#7c3aed" />
                </SectionCard>
                <SectionCard icon="✅" title="Recommended Next Steps" accentColor="#059669" bgColor="#f0fdf4" borderColor="#bbf7d0">
                  <BulletList items={result.nextSteps} color="#059669" />
                </SectionCard>
                <SectionCard icon="🏥" title="When to See a Doctor" accentColor="#dc2626" bgColor="#fef2f2" borderColor="#fecaca">
                  <BulletList items={result.whenToSeeDoctor} color="#ef4444" />
                </SectionCard>

                <div style={{ background: "#fefce8", border: "1px solid #fde68a", borderRadius: "12px", padding: "11px 14px", display: "flex", gap: "8px", alignItems: "flex-start", marginBottom: "14px" }}>
                  <span style={{ fontSize: "15px", flexShrink: 0 }}>⚠️</span>
                  <p style={{ margin: 0, fontSize: "12px", color: "#92400e", lineHeight: "1.5" }}>
                    This tool provides general health information and is not a medical diagnosis. Always consult a qualified healthcare professional.
                  </p>
                </div>

                <div style={{ display: "flex", gap: "8px", marginBottom: "16px", flexWrap: "wrap" }}>
                  <button onClick={handleReset} style={{ flex: "1 1 70px", padding: "12px 8px", borderRadius: "12px", border: "2px solid #e5e7eb", background: "white", cursor: "pointer", fontSize: "12px", fontWeight: "600", color: "#6b7280" }}>
                    🔄 Start Over
                  </button>
                  <button
                    onClick={() => generatePDF({ profile: fullProfile, durationDays, painLevel, selectedSymptoms: selectedSymptomLabels, customSymptoms, result, severity })}
                    style={{ flex: "1 1 90px", padding: "12px 8px", borderRadius: "12px", border: "none", background: "linear-gradient(135deg, #6d28d9, #7c3aed)", cursor: "pointer", fontSize: "12px", fontWeight: "600", color: "white", boxShadow: "0 4px 14px rgba(109,40,217,0.3)" }}
                  >
                    📄 Download Report
                  </button>
                  <FindDoctorButton />
                </div>
              </div>
            </div>
          )}

          {/* ── Always-visible Disclaimer ── */}
          <div style={{ background: "rgba(255,255,255,0.75)", border: "1px solid #bae6fd", borderRadius: "14px", padding: "13px 16px", display: "flex", gap: "8px", alignItems: "flex-start", marginBottom: "12px" }}>
            <span style={{ fontSize: "15px", flexShrink: 0 }}>🛡️</span>
            <p style={{ margin: 0, fontSize: "12px", color: "#374151", lineHeight: "1.6" }}>
              <strong>Disclaimer:</strong> This tool is not a medical diagnosis. Please consult a healthcare professional for medical advice.
            </p>
          </div>

          <p style={{ textAlign: "center", fontSize: "11px", color: "#9ca3af", margin: "0 0 24px" }}>🔒 Your health data stays private and on-device</p>
        </div>
      </div>
    </div>
  );
}
