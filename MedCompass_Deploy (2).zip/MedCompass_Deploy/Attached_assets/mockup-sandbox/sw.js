// ─── MedCompass Service Worker ────────────────────────────────────────────────
// Supports: offline caching, background sync, periodic sync, push notifications

const CACHE_NAME = "medcompass-cache-v3";
const OFFLINE_URL = "/__mockup/preview/MedCompass";

const PRECACHE_URLS = [
  "/__mockup/preview/MedCompass",
  "/__mockup/manifest.json",
  "/__mockup/icons/icon-192.png",
  "/__mockup/icons/icon-512.png",
  "/__mockup/icons/apple-touch-icon.png",
];

const PUSH_MESSAGES = [
  { title: "MedCompass", body: "Remember to drink water today 💧", icon: "/__mockup/icons/icon-192.png" },
  { title: "MedCompass", body: "Your daily health tip is available 🌿", icon: "/__mockup/icons/icon-192.png" },
  { title: "MedCompass", body: "Check your health status today 🩺", icon: "/__mockup/icons/icon-192.png" },
  { title: "MedCompass", body: "Stay healthy — log any new symptoms 📋", icon: "/__mockup/icons/icon-192.png" },
];

// ─── Install ──────────────────────────────────────────────────────────────────

self.addEventListener("install", (event) => {
  event.waitUntil(
    caches
      .open(CACHE_NAME)
      .then((cache) => {
        return Promise.allSettled(
          PRECACHE_URLS.map((url) =>
            fetch(url).then((res) => res.ok ? cache.put(url, res) : null).catch(() => null)
          )
        );
      })
      .then(() => self.skipWaiting())
  );
});

// ─── Activate ─────────────────────────────────────────────────────────────────

self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches
      .keys()
      .then((keys) =>
        Promise.all(keys.filter((k) => k !== CACHE_NAME).map((k) => caches.delete(k)))
      )
      .then(() => self.clients.claim())
  );
});

// ─── Fetch ────────────────────────────────────────────────────────────────────

self.addEventListener("fetch", (event) => {
  const { request } = event;
  const url = new URL(request.url);

  // Skip non-GET and cross-origin requests
  if (request.method !== "GET" || url.origin !== self.location.origin) return;

  // Network-first for HTML navigation → fall back to cached offline shell
  if (request.mode === "navigate") {
    event.respondWith(
      fetch(request)
        .then((res) => {
          if (res.ok) {
            const clone = res.clone();
            caches.open(CACHE_NAME).then((c) => c.put(request, clone));
          }
          return res;
        })
        .catch(() =>
          caches.match(request).then((r) => r || caches.match(OFFLINE_URL))
        )
    );
    return;
  }

  // Cache-first for static assets
  if (/\.(js|css|png|svg|ico|woff2?|ttf|webp|jpg)$/.test(url.pathname) ||
      url.pathname.startsWith("/__mockup/icons/")) {
    event.respondWith(
      caches.match(request).then(
        (cached) =>
          cached ||
          fetch(request).then((res) => {
            if (res.ok) {
              const clone = res.clone();
              caches.open(CACHE_NAME).then((c) => c.put(request, clone));
            }
            return res;
          })
      )
    );
    return;
  }

  // Default: stale-while-revalidate
  event.respondWith(
    caches.match(request).then((cached) => {
      const networkFetch = fetch(request).then((res) => {
        if (res.ok) {
          const clone = res.clone();
          caches.open(CACHE_NAME).then((c) => c.put(request, clone));
        }
        return res;
      });
      return cached || networkFetch;
    })
  );
});

// ─── Background Sync ──────────────────────────────────────────────────────────
// Queues report-generation requests made offline and retries when back online

self.addEventListener("sync", (event) => {
  if (event.tag === "sync-health-reports") {
    event.waitUntil(syncPendingReports());
  }
});

async function syncPendingReports() {
  try {
    const db = await openReportDB();
    const tx = db.transaction("pending-reports", "readwrite");
    const store = tx.objectStore("pending-reports");
    const reports = await idbGetAll(store);
    for (const report of reports) {
      // In production this would POST to a server; here we log and clear.
      console.log("[MedCompass SW] Syncing queued report:", report.id);
      store.delete(report.id);
    }
  } catch (err) {
    console.warn("[MedCompass SW] Background sync failed:", err);
  }
}

// ─── Periodic Background Sync ─────────────────────────────────────────────────
// Refreshes health tips content when the user's device has network connectivity

self.addEventListener("periodicsync", (event) => {
  if (event.tag === "update-health-tips") {
    event.waitUntil(refreshHealthTips());
  }
});

async function refreshHealthTips() {
  try {
    const cache = await caches.open(CACHE_NAME);
    // Re-fetch and update cached app shell so tips data stays fresh
    const response = await fetch(OFFLINE_URL);
    if (response.ok) await cache.put(OFFLINE_URL, response);
    console.log("[MedCompass SW] Health tips refreshed via periodic sync");
  } catch (err) {
    console.warn("[MedCompass SW] Periodic sync failed:", err);
  }
}

// ─── Push Notifications ───────────────────────────────────────────────────────

self.addEventListener("push", (event) => {
  let data = { title: "MedCompass", body: "A new health update is available." };
  try {
    if (event.data) data = event.data.json();
  } catch {
    const random = PUSH_MESSAGES[Math.floor(Math.random() * PUSH_MESSAGES.length)];
    data = random;
  }

  event.waitUntil(
    self.registration.showNotification(data.title || "MedCompass", {
      body: data.body || "Check your health status.",
      icon: "/__mockup/icons/icon-192.png",
      badge: "/__mockup/icons/icon-192.png",
      vibrate: [100, 50, 100],
      data: { url: OFFLINE_URL },
      actions: [
        { action: "open", title: "Open App" },
        { action: "dismiss", title: "Dismiss" },
      ],
    })
  );
});

self.addEventListener("notificationclick", (event) => {
  event.notification.close();
  if (event.action === "dismiss") return;
  event.waitUntil(
    self.clients.matchAll({ type: "window", includeUncontrolled: true }).then((clients) => {
      for (const client of clients) {
        if (client.url.includes("/__mockup") && "focus" in client) return client.focus();
      }
      if (self.clients.openWindow) return self.clients.openWindow(OFFLINE_URL);
    })
  );
});

// ─── IndexedDB helpers (for background sync queue) ───────────────────────────

function openReportDB() {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open("medcompass-reports", 1);
    req.onupgradeneeded = () => req.result.createObjectStore("pending-reports", { keyPath: "id" });
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

function idbGetAll(store) {
  return new Promise((resolve, reject) => {
    const req = store.getAll();
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}
